// Miles Bookstaber | 4 Mar 2026 | ShapeGame
int x, y, tx, ty, score;
float tw;
PImage player, target;


void setup() {
size(500, 500);
x = width/2;
y = height/2;
tx = int(random(20, width-20));
ty = int(random(20, height-20));
tw = 100;
score = 0;
player = loadImage("piskelly3.png");
target = loadImage("piskelly3.png");
}

void draw() {
background(127);
scorePanel();
target();
imageMode(CENTER);
image(player, x, y);
}


void gameOver() {
background(0);
fill(255, 0, 0);
textSize(40);
text("Game Over", width/2, height/2);
noLoop();
}

void target() {
float d = dist(x, y, tx, ty);
println(d);
if (d<50) {
score = score + 1;
tx = int(random(20, width-20));
ty = int(random(20, height-20));
tw = 200;
}
rectMode(CENTER);
if (tw<10) {
gameOver();
}
image(target, tx, ty);
tw = tw - 0.1;
target.resize(int(tw), int(tw));
}
void scorePanel() {
rectMode(CENTER);
fill(127, 127);
rect(tx, ty, tw, tw);
tw = tw - 1;
fill(0);
text("Score:" + score, 4000, 25);
}

void keyPressed() {
//edge looping
if (x > width) {
x = 0;
}

if (x < 0) {
x = width;
}

//WASD and Arrow Movement
if (key == 'w' || key == 'W' || keyCode == UP) {
y = y - 10;
} else if (key == 's' || key == 'S' || keyCode == DOWN) {
y = y + 10;
} else if (key == 'a' || key == 'A' || keyCode == LEFT) {
x = x - 10;
} else if (key == 'd' || key == 'D' || keyCode == RIGHT) {
x = x + 10;
}
}
